@app.route('/compile', methods=['POST'])
    def compile(  ):
        # get main.c ...
        
        -----
        10 users input 
        
        
        compiled or not
        
        
        
        
        
        ------
        
        send 